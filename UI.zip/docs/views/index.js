import Mark from './mark.vue'

export {
    Mark
}
