<style  lang = "sass" >


</style>
<template>
  <div>1212</div>
</template>
<script>
import 'bootstrap/dist/js/bootstrap.js'

  export default {
     vuex: {
      getters: {
       // userId: ({ mResorce })=> mResorce.datas
      },

      actions: {
         
            
      }
    },
    components: { 
          },
    ready() {
       
    },
    data () {
      return {
       
        
      }
    },
    events: {
      
    },
    methods:{
       
    },
    
   
    created() {
        

    }

  }


</script>