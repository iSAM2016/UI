/**
 * Created by aresn on 16/7/18.
 */

import Env from './env';

var config = {
    env: Env
};
module.exports = config;